package com.example.practica2tenipuclla

import androidx.lifecycle.ViewModel

class TeamsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}